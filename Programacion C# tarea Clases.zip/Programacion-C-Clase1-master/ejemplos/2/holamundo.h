void imprime_nombre(char *nombre);
