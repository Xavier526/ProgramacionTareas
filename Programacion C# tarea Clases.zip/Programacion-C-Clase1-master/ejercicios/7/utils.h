/* Declarar en este fichero la función que queremos exportar a otros ficheros */
