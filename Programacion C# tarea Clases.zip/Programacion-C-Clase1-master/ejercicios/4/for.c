/* Realizar el ejercicio que hemos realizado con while pero usando
 * el bucle for
 */


/* Bibliotecas a incluir */

void main()
{
	/* Declaración de variables */

	/* Código usando condicional while */
}
